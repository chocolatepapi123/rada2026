import React, { useEffect, useState } from 'react';
import { 
  X, 
  MapPin, 
  Phone, 
  Instagram, 
  ExternalLink, 
  MessageCircle, 
  Calendar, 
  Tag, 
  Sparkles, 
  Store, 
  Ticket, 
  Percent, 
  Copy, 
  Check, 
  Clock, 
  UtensilsCrossed, 
  Share2 
} from 'lucide-react';
import { 
  BusinessAccount, 
  BusinessOffer, 
  SpotItem, 
  EventItem 
} from '../types.ts';
import { VerifiedBadge } from './VerifiedBadge.tsx';
import { MerchantVerificationBadge } from './MerchantVerificationBadge.tsx';
import { isBusinessApproved, PublicTierBadges } from './BusinessBadge.tsx';
import { usePublicTiers } from '../lib/subscriptions';
import { track } from '../lib/tracking';

import { shareContent } from '../utils/shareUtils.ts';
import { getSpotCategoryAccent } from '../lib/spotAccents.ts';
import { getSpotCategoryIds } from '../lib/spotCategories.ts';
import { ClaimOfferButton } from './RetentionBits';
import { sortPremium } from '../lib/spotRanking.ts';
import type { ToastOptions } from './Toast.tsx';

interface PublicBusinessProfileModalProps {
  business: BusinessAccount | null;
  onClose: () => void;
  offers: BusinessOffer[];
  spots: SpotItem[];
  events: EventItem[];
  onOpenSpotDetails?: (spot: SpotItem) => void;
  onOpenEventDetails?: (event: EventItem) => void;
  showToast: (msg: string, options?: ToastOptions) => void;
}

export const PublicBusinessProfileModal: React.FC<PublicBusinessProfileModalProps> = ({
  business,
  onClose,
  offers,
  spots,
  events,
  onOpenSpotDetails,
  onOpenEventDetails,
  showToast
}) => {
 const [copiedCodeId, setCopiedCodeId] = useState<string | null>(null);
  // Public tier of the business owner (Business / Golden Featured). Hook runs before the early return.
  const ownerTiers = usePublicTiers([business?.ownerId]);
  // One 'view' per business per session (de-duplicated inside track()).
  useEffect(() => {
    if (business?.id) track('view', 'business', business.id);
  }, [business?.id]);
  if (!business) return null;

  // Filter offers for this business
  const businessOffers = offers.filter(o => o.businessId === business.id);

  // Filter spots and events for this business
  const businessSpots = spots.filter(s => s.businessId === business.id);
  const businessEvents = events.filter(e => e.businessId === business.id);

  const handleCopyCode = async (offerId: string, code?: string) => {
    if (!code) return;
    let copied = false;
    try {
      await navigator.clipboard.writeText(code);
      copied = true;
    } catch {
      // older phones / blocked clipboard: try the classic way
      try {
        const ta = document.createElement('textarea');
        ta.value = code;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        copied = document.execCommand('copy');
        document.body.removeChild(ta);
      } catch { /* give up quietly */ }
    }
    if (!copied) return;
    if (business) track('offer_redeem', 'business', business.id);
    setCopiedCodeId(offerId);
    setTimeout(() => setCopiedCodeId(null), 2500);
  };

  const handleShareProfile = () => {
    shareContent({
      title: `${business.name} on RADA`,
      text: `Check out ${business.name} in ${business.neighborhood}, Nairobi! ${business.bio}`,
      url: window.location.href,
      onError: (m: string) => showToast?.(m, { type: 'error' })
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-white dark:bg-[#121113] animate-in fade-in duration-150">
      <div className="bg-white dark:bg-[#121113] text-slate-900 dark:text-slate-100 w-full h-full flex flex-col overflow-y-auto animate-in slide-in-from-bottom duration-200">
        
        {/* Cover Photo & Header Buttons */}
        <div className="relative h-72 sm:h-96 w-full bg-slate-900 shrink-0">
          <img loading="lazy" decoding="async" 
            src={business.coverImage || business.logo} 
            alt={business.name} 
            className="w-full h-full object-cover opacity-90" 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
          
          <div className="absolute right-3 flex items-center gap-2" style={{ top: 'calc(env(safe-area-inset-top, 0px) + 0.75rem)' }}>
            <button 
              type="button"
              onClick={handleShareProfile}
              className="w-8 h-8 rounded-full bg-black/60 backdrop-blur-md text-white flex items-center justify-center hover:bg-black transition cursor-pointer"
              title="Share Profile / Link"
              aria-label="Share Profile"
            >
              <Share2 className="w-3.5 h-3.5" />
            </button>
            <button 
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-black/60 backdrop-blur-md text-white flex items-center justify-center hover:bg-black transition cursor-pointer"
              aria-label="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Business Type Badge */}
          <div className="absolute left-3" style={{ top: 'calc(env(safe-area-inset-top, 0px) + 0.75rem)' }}>
            {isBusinessApproved(business) && (
              <MerchantVerificationBadge category={business.category} size="sm" />
            )}
          </div>
        </div>

        {/* Scrollable Profile Body */}
        <div className="p-5 pb-24 space-y-6 flex-1 w-full max-w-2xl mx-auto">
          {/* Main Info */}
          <div className="relative -mt-12 flex items-end gap-3.5">
            <img loading="lazy" decoding="async" 
              src={business.logo} 
              alt={business.name} 
              className="w-20 h-20 rounded-2xl object-cover border-4 border-white dark:border-[#1C1A1E] shadow-xl shrink-0" 
            />
            <div className="flex-1 min-w-0 pb-1">
              <h2 className="text-xl font-black tracking-tight leading-tight truncate">
                {business.name}
              </h2>
              <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                <MapPin className="w-3 h-3 text-[#E0533C] dark:text-[#D17A68] shrink-0" />
                <span className="truncate">{business.address || `${business.neighborhood}, Nairobi`}</span>
              </div>
              {isBusinessApproved(business) && (
                <p className="mt-1.5 inline-flex items-center gap-1.5 text-[11px] font-black text-[#E0533C] dark:text-[#D17A68]">
                  <VerifiedBadge status="approved" size="sm" />
                  <span>Verified by RADA</span>
                </p>
              )}
              {!isBusinessApproved(business) && business.verificationStatus !== 'rejected' && (
                <p className="mt-1.5 inline-flex items-center text-[11px] font-black px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                  New · awaiting RADA verification
                </p>
              )}
              <PublicTierBadges
                tiers={business.ownerId ? ownerTiers[business.ownerId] : undefined}
                kinds={['merchant']}
                merchantApproved={isBusinessApproved(business)}
                size="sm"
                className="mt-2.5"
              />
            </div>
          </div>

          {/* Bio */}
          <div className="bg-[#FBFBF9] dark:bg-[#121113] p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
            <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
              {business.bio}
            </p>
          </div>

          {/* Quick Contact & Action Buttons */}
          <div className="grid grid-cols-3 gap-2">
            {business.whatsapp && (
              <a
                href={`https://wa.me/${business.whatsapp.replace(/[^0-9]/g, '')}`}
                onClick={() => track('whatsapp', 'business', business.id)}
                target="_blank"
                rel="noreferrer"
                className="p-2.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30 rounded-xl text-center text-xs font-bold flex items-center justify-center gap-1.5 transition"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>WhatsApp</span>
              </a>
            )}

            {business.phone && (
              <a
                href={`tel:${business.phone}`}
                onClick={() => track('call', 'business', business.id)}
                className="p-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-center text-xs font-bold flex items-center justify-center gap-1.5 transition"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call Venue</span>
              </a>
            )}

            {business.instagram && (
              <a
                href={`https://instagram.com/${business.instagram.replace('@', '')}`}
                onClick={() => track('website', 'business', business.id)}
                target="_blank"
                rel="noreferrer"
                className="p-2.5 bg-pink-500/10 hover:bg-pink-500/20 text-pink-700 dark:text-pink-400 border border-pink-500/30 rounded-xl text-center text-xs font-bold flex items-center justify-center gap-1.5 transition truncate"
              >
                <Instagram className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{business.instagram}</span>
              </a>
            )}
          </div>

          {/* ========================================================
              ACTIVE PROMOTIONS & OFFERS SHOWCASE (SPEC 4)
              ======================================================== */}
          {businessOffers.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <Percent className="w-3.5 h-3.5 text-[#E0533C] dark:text-[#D17A68]" />
                  <span>Running Offers & Deals ({businessOffers.length})</span>
                </h3>
                <span className="text-[10px] font-bold text-rose-500">Live Promotions</span>
              </div>

              <div className="space-y-3">
                {businessOffers.map(offer => (
                  <div 
                    key={offer.id}
                    className="bg-white dark:bg-[#121113] border border-rose-500/30 dark:border-rose-500/20 rounded-2xl overflow-hidden shadow-xs"
                  >
                    {offer.posterUrl && (
                      <div className="h-32 w-full relative">
                        <img loading="lazy" decoding="async" src={offer.posterUrl} alt={offer.title} className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                        <span className="absolute top-2 left-2 bg-[#E0533C] dark:bg-[#A94F3E] text-white text-[9px] font-black px-2 py-0.5 rounded-md shadow-xs">
                          {offer.discount}
                        </span>
                        <span className="absolute top-2 right-2 bg-black/60 text-white text-[9px] font-bold px-2 py-0.5 rounded-md">
                          {offer.category}
                        </span>
                        <div className="absolute bottom-2 left-2 right-2">
                          <p className="text-[10px] text-amber-300 font-semibold">{offer.validUntil}</p>
                          <h4 className="text-xs font-black text-white">{offer.title}</h4>
                        </div>
                      </div>
                    )}

                    <div className="p-3 space-y-2">
                      <p className="text-[11px] text-slate-600 dark:text-slate-300">
                        {offer.description}
                      </p>

                      {offer.claimCode ? (
                      <div className="flex items-center justify-between pt-1">
                          <span className="text-[10px] font-mono font-bold bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-lg text-slate-700 dark:text-slate-300">
                            Code: {offer.claimCode || 'RADADEAL'}
                          </span>

                          <button
                            onClick={() => handleCopyCode(offer.id, offer.claimCode || 'RADADEAL')}
                            className="px-3 py-1 bg-[#E0533C] dark:bg-[#A94F3E] hover:bg-[#c9432d] dark:hover:bg-[#8F4334] text-white text-xs font-bold rounded-lg flex items-center gap-1 transition"
                          >
                            {copiedCodeId === offer.id ? (
                              <>
                                <Check className="w-3 h-3" />
                                <span>Copied!</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3 h-3" />
                                <span>Claim Code</span>
                              </>
                            )}
                          </button>
                        </div>
                                              ) : (
                        <div className="space-y-1.5 pt-1">
                          {(offer.venue || offer.location) && (
                            <p className="text-[11px] font-bold text-slate-700 dark:text-slate-200">
                              {[offer.venue, offer.location].filter(Boolean).join(' · ')}
                            </p>
                          )}
                          {offer.audience && offer.audience !== 'Everyone' && (
                            <p className="text-[10px] font-bold text-slate-500">For: {offer.audience}</p>
                          )}
                          <div className="flex items-center gap-2">
                            {offer.contactPhone && (
                              <a href={`tel:${offer.contactPhone.replace(/\s+/g, '')}`} className="px-3 py-1.5 bg-[#E0533C] dark:bg-[#A94F3E] text-white text-xs font-bold rounded-lg">Call</a>
                            )}
                            {(offer.bookingUrl || offer.actionUrl) && (
                              <a href={offer.bookingUrl || offer.actionUrl} target="_blank" rel="noopener noreferrer" className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 text-xs font-bold rounded-lg">Book / more info</a>
                            )}
                          </div>
                        </div>
                      )}
                      {offer.terms && <p className="text-[10px] text-slate-400 pt-1">{offer.terms}</p>}
                      {offer.claimCode && <div className="pt-2"><ClaimOfferButton offerId={offer.id} /></div>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ========================================================
              VERTICAL-SPECIFIC SHOWCASE
              ======================================================== */}
          {/* Spots Showcase */}
          {business.category === 'hospitality' && businessSpots.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <Store className="w-3.5 h-3.5 text-amber-500" />
                <span>{isBusinessApproved(business) ? 'Verified Spots' : 'Spots'} ({businessSpots.length})</span>
              </h3>
              <div className="space-y-2">
                {sortPremium([...businessSpots]).map(spot => {
                  const ids = getSpotCategoryIds(spot);
                  const accents = (ids.length ? ids : [spot.category]).map(c => getSpotCategoryAccent(c));
                  const primary = accents[0];
                  return (
                  <div 
                    key={spot.id}
                    onClick={() => {
                      onClose();
                      onOpenSpotDetails && onOpenSpotDetails(spot);
                    }}
                    className="p-3 bg-[#FBFBF9] dark:bg-[#121113] border border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-between gap-3 cursor-pointer transition"
                    style={{ borderLeftColor: primary.color, borderLeftWidth: 4 }}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <img loading="lazy" decoding="async" src={spot.img} alt={spot.title} className="w-12 h-12 rounded-xl object-cover shrink-0" />
                      <div className="min-w-0">
                        <div className="flex flex-wrap gap-1 mb-0.5">
                          {accents.slice(0, 2).map(a => (
                            <span
                              key={a.id}
                              className="text-[9px] font-black px-1.5 py-0.5 rounded-md flex items-center gap-1"
                              style={{ backgroundColor: a.soft, color: a.color, border: `1px solid ${a.border}` }}
                            >
                              <a.Icon className="w-2.5 h-2.5" />{a.label}
                            </span>
                          ))}
                        </div>
                        <h4 className="font-extrabold text-xs truncate">{spot.title}</h4>
                        <p className="text-[10px] text-slate-400 truncate">{spot.exactLocationTag || spot.address}</p>
                        <p className="text-[10px] text-amber-600 font-bold">{spot.rating}/5 • {spot.menuItems?.length || 0} menu items</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold shrink-0" style={{ color: primary.color }}>View Spot →</span>
                  </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Events Showcase */}
          {business.category === 'event_organizer' && businessEvents.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <Ticket className="w-3.5 h-3.5 text-purple-500" />
                <span>Upcoming Events ({businessEvents.length})</span>
              </h3>
              <div className="space-y-2">
                {businessEvents.map(evt => (
                  <div 
                    key={evt.id}
                    onClick={() => {
                      onClose();
                      onOpenEventDetails && onOpenEventDetails(evt);
                    }}
                    className="p-3 bg-[#FBFBF9] dark:bg-[#121113] border border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-between gap-3 cursor-pointer hover:border-purple-400 transition"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <img loading="lazy" decoding="async" src={evt.img} alt={evt.title} className="w-12 h-12 rounded-xl object-cover shrink-0" />
                      <div className="min-w-0">
                        <h4 className="font-extrabold text-xs truncate">{evt.title}</h4>
                        <p className="text-[10px] text-purple-600 font-bold">{evt.date}</p>
                        <p className="text-[10px] text-slate-400 truncate">{evt.location}</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-purple-600 shrink-0">Tickets →</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Discography / Lookbook media */}
          {business.discography && business.discography.length > 0 && (
            <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Media & Curated Discography
              </h3>
              <div className="space-y-1.5">
                {business.discography.map((disco, i) => (
                  <div key={i} className="p-2.5 bg-[#FBFBF9] dark:bg-[#121113] rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-800 dark:text-slate-200">{disco}</span>
                    <span className="text-[9px] bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-bold px-2 py-0.5 rounded">
                      Showcase
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
